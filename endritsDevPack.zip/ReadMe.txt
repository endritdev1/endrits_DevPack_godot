Eveything here is work in progress.
It was thought to speed up my game dev and not reinvent each time the wheel.
Feel free to use and havee fun